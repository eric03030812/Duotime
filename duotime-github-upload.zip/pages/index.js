
import Head from 'next/head';
import DuoTimeLanding from '../components/DuoTimeLanding';

export default function Home() {
  return (
    <>
      <Head>
        <title>DuoTime</title>
        <meta name="description" content="L'application pour les couples : nounou, resto, transport." />
      </Head>
      <DuoTimeLanding />
    </>
  );
}
