import { motion } from "framer-motion";

export default function DuoTimeLanding() {
  return (
    <main className="bg-[#fdfdfb] text-[#2e2e2e] font-sans">
      <section className="text-center py-20 px-6 max-w-4xl mx-auto">
        <motion.h1 
          className="text-5xl font-serif mb-4"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          DuoTime
        </motion.h1>
        <p className="text-xl max-w-xl mx-auto text-[#555]">
          Une application pensée pour les couples, pour leur offrir des moments de qualité sans stress : restaurant, nounou, transport, tout est pris en charge.
        </p>
        <a href="#inscription" className="inline-block mt-8 px-6 py-3 text-lg rounded-2xl shadow-md bg-black text-white hover:bg-gray-800 transition">
          Découvrir DuoTime
        </a>
      </section>

      <section id="inscription" className="py-16 px-6 bg-white">
        <div className="max-w-md mx-auto text-center">
          <h3 className="text-3xl font-serif mb-4">Restez informé·e</h3>
          <p className="mb-4 text-[#555]">Inscrivez-vous pour recevoir les dernières nouvelles, la date de lancement, et accéder à la bêta !</p>
          <form
            action="https://formspree.io/f/xgvaregd"
            method="POST"
            className="flex flex-col sm:flex-row gap-3 items-center justify-center"
          >
            <input
              type="email"
              name="email"
              required
              placeholder="Votre email"
              className="border border-gray-300 px-4 py-2 rounded-xl w-full max-w-xs"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-black text-white rounded-2xl hover:bg-gray-800 transition"
            >
              S'inscrire
            </button>
          </form>
        </div>
      </section>

      <footer className="text-center py-6 text-sm text-[#999]">
        &copy; {new Date().getFullYear()} DuoTime. Tous droits réservés.
      </footer>
    </main>
  );
}
